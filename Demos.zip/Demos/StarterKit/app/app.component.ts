import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
      <h1> Home Page ! </h1>

      <nav>
          <a routerLink="/posts" class="btn btn-primary">Posts </a>
          <a routerLink="/about" class="btn btn-primary">About </a>
          
      </nav>


      <router-outlet></router-outlet>
  
  
  `,
})
export class AppComponent  { name = 'Angular'; }
