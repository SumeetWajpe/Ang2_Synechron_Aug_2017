import {Http} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()  // If Service makes use of another service
export class PostsService{
    constructor(private httpObj:Http){

    }

//    getPosts(callBackFunc:any){
//         // make ajaxified request to get the data !
// this.httpObj.get('https://jsonplaceholder.typicode.com/posts').subscribe((res) =>{ 
//     //console.log(res.json());
// callBackFunc(res.json());
// });

//     } 

 getPosts(){ 
return this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
    } 
}