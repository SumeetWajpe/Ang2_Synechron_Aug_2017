import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import {RouterModule,Routes} from '@angular/router';
import {AboutComponent} from './about.component';
import { AppComponent }  from './app.component';
import {PostsComponent} from './posts.component';

import {PostDetailsComponent} from './postdetails.component';

const routes:Routes =[
  {path:'about',component:AboutComponent},
  {path:'post/:id',component:PostDetailsComponent},
  
  {path:'posts',component:PostsComponent} ,
  {path:'',redirectTo:'/posts',pathMatch:'full'},
  {path:'**',redirectTo:'/about',pathMatch:'full'}
  
];


@NgModule({
  imports:      [ BrowserModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,AboutComponent,PostsComponent,PostDetailsComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
