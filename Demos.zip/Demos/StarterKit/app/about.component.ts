import { Component } from '@angular/core';

@Component({
  selector: 'about',
  template: `<h1> About {{name}} ! </h1>
  <p> Refer angular Documentation to know more about Angular 2-> http://angular.io
 </p>`,
})
export class AboutComponent  { 
    name = 'Angular';
 }
