import {Component} from '@angular/core';
import {PostsService} from './posts.service';

@Component({
    selector:'posts',
    template:`<h1> Posts </h1>
    
        <ul>
            <li *ngFor="let post of postsData">
                  <a [routerLink]="['/post',post.id]">  {{post.title}} </a>
            </li>
        </ul>
    
    
    `,
    providers:[PostsService]
})
export class PostsComponent{
    postsData:any[] =[];
    constructor(private servObj:PostsService){        
            // this.servObj.getPosts((dataFromService:any)=>{
            //     this.postsData = dataFromService;
            // });
            }

            ngOnInit(){
                let returnedPromise = this.servObj.getPosts(); // returns a promise

                returnedPromise.then(
                    (response)=>{ this.postsData = response.json()   },
                     (error)=>{ console.log('Something went wrong ' + error) }
            ); //eof then
            } // eof ngOnInit
}